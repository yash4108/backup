package com.mindgate.main;

public class Employee {

}
